const road = document.querySelector('#road');
const context = road.getContext('2d');
const decision = document.querySelector('#decision');
const controls = document.querySelectorAll('[data-scenario]');

function drawScenario(scenario) {
  const blocked = scenario === 'blocked';
  context.fillStyle = '#170e27';
  context.fillRect(0, 0, 660, 300);
  context.fillStyle = '#3a2454';
  context.fillRect(0, 65, 660, 170);
  context.strokeStyle = '#ac8ecb';
  context.lineWidth = 2;
  context.setLineDash([18, 14]);
  context.beginPath();
  context.moveTo(0, 150);
  context.lineTo(660, 150);
  context.stroke();
  context.setLineDash([]);
  if (blocked) {
    context.fillStyle = '#ff9ce1';
    context.fillRect(405, 175, 48, 34);
  }
  context.strokeStyle = '#c4a0ff';
  context.lineWidth = 6;
  context.lineCap = 'round';
  context.beginPath();
  context.moveTo(94, 192);
  if (blocked) {
    context.bezierCurveTo(210, 192, 245, 108, 355, 108);
  }
  context.lineTo(610, blocked ? 108 : 192);
  context.stroke();
  context.fillStyle = '#fff1ff';
  context.fillRect(55, 175, 53, 34);
  road.setAttribute('aria-label', blocked ? 'Vehicle route changes lanes before the obstacle' : 'Vehicle route stays in its current lane');
  decision.lastChild.textContent = blocked ? ' Change lanes to avoid the obstacle.' : ' Continue in the current lane.';
  controls.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.scenario === scenario)));
}

controls.forEach(button => button.addEventListener('click', () => drawScenario(button.dataset.scenario)));
drawScenario('clear');
